var a = require("./a");
if(x) {
	for(var i = 0; i < 100; i++) {
		while(true)
			require("./b");
		do {
			i++;
		} while(require("m1/a")());
	}
}