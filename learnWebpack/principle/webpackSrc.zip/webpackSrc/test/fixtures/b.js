module.exports = function b() {
	return "This is b";
};