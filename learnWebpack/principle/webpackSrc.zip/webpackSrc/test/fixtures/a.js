module.exports = function a() {
	return "This is a";
};