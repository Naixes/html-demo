// This file can update, because 'index.js' accept it.

module.exports = "This text comes from <b>'html.js'</b>.";