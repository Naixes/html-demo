require("./a");
require(["./b"]);
require(["./c"]);