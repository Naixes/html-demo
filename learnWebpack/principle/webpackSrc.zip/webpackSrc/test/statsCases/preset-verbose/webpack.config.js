module.exports = {
	mode: "production",
	entry: "./index",
	profile: true,
	stats: "verbose"
};
