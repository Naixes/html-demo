import "./f";
export default "g";
