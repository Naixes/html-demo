require("./c" + __resourceQuery)
