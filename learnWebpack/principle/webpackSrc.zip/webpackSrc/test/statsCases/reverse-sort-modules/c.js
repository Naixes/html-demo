require("./b" + __resourceQuery)
