require("./a" + __resourceQuery);
