import { b, c } from './constants';

export default b + c;
