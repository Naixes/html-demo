import { a, b, c } from './constants';

export default a + b + c;
