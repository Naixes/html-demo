import d, { a } from './constants';

export default d + a;
