require.ensure(["./a"], function() {});
require(["./b"]);
import("./c");
