module.exports = {
	mode: "production",
	entry: "./index",
	stats: {
		all: false,
		chunks: true
	}
};
