module.exports = {
	mode: "production",
	entry: "./index",
	stats: "errors-only"
};
