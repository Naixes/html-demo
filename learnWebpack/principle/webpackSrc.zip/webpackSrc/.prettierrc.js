module.exports = {
	printWidth: 80,
	useTabs: true,
	tabWidth: 2
};
