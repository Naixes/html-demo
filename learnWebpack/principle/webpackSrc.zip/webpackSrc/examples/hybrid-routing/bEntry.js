// Just show the page "b"
var render = require("./render");
render(require("./bPage"));