var vendor1 = require('vendor1');
var utility1 = require('./utility1');
var utility2 = require('./utility2');

module.exports = "pageA";
