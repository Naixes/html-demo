// some async loaded module
