# example.js

``` javascript
{{example.js}}
```

# a.js


``` javascript
{{a.js}}
```

# dist/output.js

``` javascript
{{dist/output.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
