module.exports = function() {
	console.log("reusable Component");
};
