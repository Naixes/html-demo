
# example.js

``` javascript
{{example.js}}
```

# cup1.coffee

``` coffee-script
{{cup1.coffee}}
```

# cup2.coffee

``` coffee-script
{{cup2.coffee}}
```

# dist/output.js

``` javascript
{{dist/output.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```