# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# dist/vendor1.js

``` javascript
{{dist/vendor1.js}}
```

# dist/vendor2.js

``` javascript
{{dist/vendor2.js}}
```

# dist/pageA.js

``` javascript
{{dist/pageA.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
