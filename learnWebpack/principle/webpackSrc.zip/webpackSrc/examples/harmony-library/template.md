# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# dist/MyLibrary.umd.js

``` javascript
{{dist/MyLibrary.umd.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
