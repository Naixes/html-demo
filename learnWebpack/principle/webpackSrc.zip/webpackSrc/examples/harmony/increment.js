import { add } from './math';
export function increment(val) {
    return add(val, 1);
};
